
	motion_set(90,  7);