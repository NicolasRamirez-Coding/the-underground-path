


if position_meeting(mouse_x, mouse_y, exitt) {
	sprite_index = Exit_Glow;
}

else {
	sprite_index = Exit;
}