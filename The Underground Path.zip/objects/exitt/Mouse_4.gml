

if position_meeting(mouse_x, mouse_y, exitt) {
	room_goto(Menus);
}