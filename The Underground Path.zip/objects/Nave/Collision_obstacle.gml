effect_create_above(ef_explosion, x, y, 2, #7D4A17);
instance_destroy();
Barra.x = 480;

if global.endless == 1 {
	Logic.alarm[3] = 120;
}
else {
	Logic.alarm[1] = 120;
}

