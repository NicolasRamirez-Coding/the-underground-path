effect_create_above(ef_explosion, x, y, 2, #7D4A17);
instance_destroy();
Logic.alarm[3] = 120;
