instance_destroy(other);

if Barra.x == 576 {
BarraSalva.x += 19.2;
}
else {
	BarraSalva.sprite_index = Barra4;
	BarraSalva.alarm[2] = 15;
}

