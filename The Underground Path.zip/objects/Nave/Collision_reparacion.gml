instance_destroy(other);

if Barra.x != 576 {
Barra.x += 96/5;
Barra.sprite_index = Barra5;
Barra.alarm[2] = 15;
}

