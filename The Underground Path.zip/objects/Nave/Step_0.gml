

if keyboard_check(vk_right) {
	motion_add(0, 0.05);
	if image_angle > -12 {
		image_angle -= 1;
	}
	effect_create_above(ef_spark, (x-10), (y+30), 0.3, c_white);
}

if keyboard_check(vk_left) {
	motion_add(0, -0.05);
		if image_angle < 12 {
		image_angle += 1;
	}
	effect_create_above(ef_spark, (x+60), (y+30), 0.3, c_white);

}

if !keyboard_check(vk_right) && !keyboard_check(vk_left) {
	if speed > 0 {
		speed -= 0.05;
		
	}
	
	if speed < 0 {
		speed += 0.05;
		
	}
	
	if image_angle > 0 {
		image_angle -= 1;
	}
	

	
	if image_angle < 0 {
		image_angle += 1;
	}
}

if Barra.x <= 480 {
	effect_create_above(ef_explosion, x, y, 2, c_red);
	instance_destroy();
	Logic.alarm[1] = 120;
}