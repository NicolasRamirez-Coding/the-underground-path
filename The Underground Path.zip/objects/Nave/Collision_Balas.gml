effect_create_above(ef_explosion, x, y, 1, c_green);
instance_destroy(other);
Barra.x -= 96/5;

Barra.sprite_index = Barra4;
Barra.alarm[2] = 15;