if x <= 480 {	
	if global.verifyBar {
	if global.endless == 1 {
		Logic.alarm[3] = 120;
	}
	else {
		Logic.alarm[1] = 120;
	}
	global.verifyBar = false;
	}
}