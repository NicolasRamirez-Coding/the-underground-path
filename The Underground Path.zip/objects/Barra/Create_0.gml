x = 576;
global.verifyBar = true;