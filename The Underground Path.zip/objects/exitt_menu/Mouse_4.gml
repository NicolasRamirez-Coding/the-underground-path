

if position_meeting(mouse_x, mouse_y, exitt_menu) {
	game_end();
}