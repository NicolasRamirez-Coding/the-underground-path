


if position_meeting(mouse_x, mouse_y, exitt_menu) {
	sprite_index = Exit_Glow;
}

else {
	sprite_index = Exit;
}