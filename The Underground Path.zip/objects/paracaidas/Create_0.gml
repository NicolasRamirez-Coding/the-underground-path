x = random_range(90, 620);
y = 700;
image_xscale = 3;
image_yscale = 3;