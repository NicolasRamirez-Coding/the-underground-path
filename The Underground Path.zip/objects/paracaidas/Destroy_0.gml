instance_create_layer(random_range(90, 620), random_range(720, 1500),"Instances_1", paracaidas);
