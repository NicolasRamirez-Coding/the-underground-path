
if x < -20 {
	instance_destroy();
}

motion_set(90, 5);