global.count_enemy = true;

global.dir = 0;
