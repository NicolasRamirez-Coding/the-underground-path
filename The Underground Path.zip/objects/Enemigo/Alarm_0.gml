instance_create_layer(x+48, y, "Instances_1", Balas);
global.count_enemy = true;