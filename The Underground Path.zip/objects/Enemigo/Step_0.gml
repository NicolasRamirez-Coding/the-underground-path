
if global.count_enemy { 
	Enemigo.alarm[0] = (random_range(15, 90) + random_range (15, 90));
	global.count_enemy = false;
}

motion_set(global.dir, 5);


	
