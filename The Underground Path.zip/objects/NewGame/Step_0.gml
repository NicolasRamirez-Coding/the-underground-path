
if position_meeting(mouse_x, mouse_y, NewGame) {
	sprite_index = New_Game_Glow;
}

else {
	sprite_index = New_Game;
}