

if position_meeting(mouse_x, mouse_y, NewGame) {
	room_goto(Cave);
	global.endless = 0;
}