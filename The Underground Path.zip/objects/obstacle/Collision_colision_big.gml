if global.est = 1 || global.est = 0 {
	global.est = irandom_range(0, 2);

	show_debug_message("EVENTO ACTIVO");
	show_debug_message(global.est);
	if global.est == 0 {
		obstacle.y = 704;
		sprite_index = EstalactitaI;
		x = 64;



	} else if global.est == 1 {
		obstacle.y = 704;
		sprite_index = EstalactitaD;
		x = 384;


	} else {
		obstacle.y = 736;
		sprite_index = EstalactitaB;
		x = 64;


	}
}