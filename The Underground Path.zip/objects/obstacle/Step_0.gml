
show_debug_message(y);
show_debug_message(global.est);
motion_set(90, global.vel);
if global.vel != 5 { 
	global.vel += 0.1;
}
