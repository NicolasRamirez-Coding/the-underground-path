



global.vel = 1;
	global.est = irandom_range(0, 2);

	if global.est == 0 {
		obstacle.y = 704;
		sprite_index = EstalactitaI;
		x = 64;
		global.disp = 160;
	

	} else if global.est == 1 {
		obstacle.y = 704;
		sprite_index = EstalactitaD;
		x = 384;
		global.disp = 160;

	} else {
		obstacle.y = 736;
		sprite_index = EstalactitaB;
		x = 64;
		global.disp = 96;

	}