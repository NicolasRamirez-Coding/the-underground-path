if global.est = 2 {
	global.est = irandom_range(0, 2);

	show_debug_message("EVENTO ACTIVO");
	show_debug_message(global.est);
	if global.est == 0 {
		y = 704;
		sprite_index = EstalactitaI;
		x = 64;



	} else if global.est == 1 {
		y = 704;
		sprite_index = EstalactitaD;
		x = 384;


	} else {
		y = 736;
		sprite_index = EstalactitaB;
		x = 64;


	}
}

// y = 736;