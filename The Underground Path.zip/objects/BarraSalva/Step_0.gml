if x >= 576 {
	room_goto(End);
}