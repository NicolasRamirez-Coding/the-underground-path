global.verifyBar1 = true;
x = 480;
y = 644;
