

if position_meeting(mouse_x, mouse_y, NewGameEndless) {
	room_goto(Endless);
	
	global.endless = 1;
}