
if position_meeting(mouse_x, mouse_y, NewGameEndless) {
	sprite_index = Endless_Mode_Glow;
}

else {
	sprite_index = Endless_Mode;
}